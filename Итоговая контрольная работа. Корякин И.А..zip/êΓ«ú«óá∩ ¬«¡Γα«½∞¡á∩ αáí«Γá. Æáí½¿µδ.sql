DROP DATABASE IF EXISTS finish_control_work;
CREATE DATABASE finish_control_work;
USE finish_control_work;

DROP TABLE IF EXISTS pets;
CREATE TABLE pets (
	id SERIAL PRIMARY KEY,
    type_of_pets VARCHAR(50)
);

INSERT INTO pets (id, type_of_pets) VALUES
(1, 'Cat'),
(2, 'Dog'),
(3, 'Hamster');

DROP TABLE IF EXISTS Pack_animals;
CREATE TABLE Pack_animals (
	id SERIAL PRIMARY KEY,
    type_of_pack_animals VARCHAR(50)
);

INSERT INTO Pack_animals (id, type_of_pack_animals) VALUES
(1, 'Neddy'),
(2, 'Horse'),
(3, 'Camel');

-- Кошки
DROP TABLE IF EXISTS Cat;
CREATE TABLE Cat (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO Cat (name_, birthday, command) VALUES
('Мелиса', '2020-01-01', 'Лежать'),
('Василий', '2022-03-01', 'Кушать'),
('Пушистик', '2022-06-05', 'Играть');

-- Собаки
DROP TABLE IF EXISTS Dog;
CREATE TABLE Dog (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO Dog (name_, birthday, command) VALUES
('Рекс', '2018-04-01', 'Лежать'),
('Нэлли', '2023-02-01', 'Дай лапу'),
('Бим', '2019-07-08', 'Принеси');

-- Хомяки
DROP TABLE IF EXISTS Hamster;
CREATE TABLE Hamster (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO Hamster (name_, birthday, command) VALUES
('Беляк', '2023-01-02', 'Кушать'),
('Черныш', '2023-07-09', 'Кушать'),
('Дымок', '2022-12-01', 'Играть');


-- Ослики
DROP TABLE IF EXISTS Neddy;
CREATE TABLE Neddy (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO Neddy (name_, birthday, command) VALUES
('Рыжик', '2017-10-01', 'Прямо'),
('Иа', '2016-12-01', 'Кушать'),
('Крапинка', '2022-04-01', 'Играть');

-- Лошади
DROP TABLE IF EXISTS Horse;
CREATE TABLE Horse (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO Horse (name_, birthday, command) VALUES
('Спирит', '2023-11-01', 'Галоп'),
('Злыдень', '2019-08-03', 'Смирно'),
('Нали', '2022-11-01', 'Кушать');

-- Верблюды
DROP TABLE IF EXISTS Camel;
CREATE TABLE Camel (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO Camel (name_, birthday, command) VALUES
('Абдулла', '2021-02-01', 'Иди'),
('Шахерезада', '2022-05-01', 'Покажи зубы!'),
('Саид', '2023-12-01', 'Вверх');

SHOW FULL TABLES;

-- Создаем таблицу с молодыми животными
DROP TABLE IF EXISTS young_animals;
CREATE TABLE young_animals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE, 
    age VARCHAR(50),
    animal_type VARCHAR(50)
);

INSERT INTO young_animals (name_, birthday, age, animal_type)
SELECT name_, birthday, CONCAT(TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE), " год ", (TIMESTAMPDIFF(MONTH, birthday, CURRENT_DATE)%12), " мес") AS age, 'Cat' AS animal_type FROM Cat
WHERE TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE) BETWEEN 1 AND 2
UNION ALL
SELECT name_, birthday, CONCAT(TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE), " год ", (TIMESTAMPDIFF(MONTH, birthday, CURRENT_DATE)%12), " мес") AS age, 'Dog' AS animal_type FROM Dog
WHERE TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE) BETWEEN 1 AND 2
UNION ALL
SELECT name_, birthday, CONCAT(TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE), " год ", (TIMESTAMPDIFF(MONTH, birthday, CURRENT_DATE)%12), " мес") AS age, 'Hamster' AS animal_type FROM Hamster
WHERE TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE) BETWEEN 1 AND 2
UNION ALL
SELECT name_, birthday, CONCAT(TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE), " год ", (TIMESTAMPDIFF(MONTH, birthday, CURRENT_DATE)%12), " мес") AS age, 'Neddy' AS animal_type FROM Neddy
WHERE TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE) BETWEEN 1 AND 2
UNION ALL
SELECT name_, birthday, CONCAT(TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE), " год ", (TIMESTAMPDIFF(MONTH, birthday, CURRENT_DATE)%12), " мес") AS age, 'Horse' AS animal_type FROM Horse
WHERE TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE) BETWEEN 1 AND 2
UNION ALL
SELECT name_, birthday, CONCAT(TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE), " год ", (TIMESTAMPDIFF(MONTH, birthday, CURRENT_DATE)%12), " мес") AS age, 'Camel' AS animal_type FROM Camel
WHERE TIMESTAMPDIFF(YEAR, birthday, CURRENT_DATE) BETWEEN 1 AND 2;

SELECT * FROM young_animals;


-- Удаляем таблицу верблюдов
DROP TABLE Camel;

-- Создаем новую объединенную таблицу лошадей и ослов
CREATE TABLE Equines (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
    birthday DATE,
    command VARCHAR(50),
    animal_type VARCHAR(10)
);

-- Вставляем данные из таблиц лошадей и ослов в новую таблицу
INSERT INTO Equines (name_, birthday, command, animal_type)
SELECT name_, birthday, command, 'Horse' AS animal_type FROM Horse
UNION ALL
SELECT name_, birthday, command, 'Neddy' AS animal_type FROM Neddy;

-- Удаляем старые таблицы лошадей и ослов
DROP TABLE Horse;
DROP TABLE Neddy;


DROP TABLE IF EXISTS all_animals;
CREATE TABLE all_animals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_ VARCHAR(50),
	animal_type VARCHAR(50),
    birthday DATE,
    command VARCHAR(50)
);

INSERT INTO all_animals (name_, animal_type, birthday, command)
SELECT name_, 'Cat' AS animal_type, birthday, command FROM Cat
UNION ALL
SELECT name_, 'Dog' AS animal_type, birthday, command FROM Dog
UNION ALL
SELECT name_, 'Hamster' AS animal_type, birthday, command FROM Hamster
UNION ALL
SELECT name_, animal_type, birthday, command FROM Equines;

SELECT * FROM all_animals;
